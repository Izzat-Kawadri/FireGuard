# Processor-Solar-Power-Sleep-Calc

1. Use this calculator to determine what size Solar Panel you need to power your Arduino/ESP8266 or ESP32 project on battery power.

2. When there is a deficit you need a larger solar panel. On the second tab, you will notice that charging is cut-off when the battery is full as expected in any design. The cutoff is when the battery capacity is reached.

3. Also the lower section of the calculator will determine expected battery life after setting battery capacity to say 2600mAHr, the time asleep; time awake; current in sleep and current when awake.

4. The result is in days.
